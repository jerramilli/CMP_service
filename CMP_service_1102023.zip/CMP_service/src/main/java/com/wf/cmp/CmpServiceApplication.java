package com.wf.cmp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmpServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmpServiceApplication.class, args);
	}

}
