package com.wf.cmp.constants;

public class CMPconstants {

  public static final String CREATED = "Created";

  public static final String UPDATED = "Updated";

  public static final String NOT_FOUND = "NotFound";

  public static final String ID = "id";

}
