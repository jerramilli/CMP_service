package com.wf.cmp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmpServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
