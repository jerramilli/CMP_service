package com.wf.cmp.api;

import co.elastic.clients.elasticsearch.core.search.Hit;
import com.wf.cmp.model.CMPRequestBody;
import com.wf.cmp.model.CMPMetrics;
import com.wf.cmp.service.CMPService;
import java.io.IOException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class CMPController {

  @Autowired
  CMPService cmpService;

  @GetMapping(value = "/metrics/{index}",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<CMPMetrics> getMetrics(
      @PathVariable(value = "index", required = true) String index) throws IOException {

      List<Hit<Object>> response = cmpService.read(index);
      CMPMetrics cmpMetrics = new CMPMetrics(response);
      return ResponseEntity.ok(cmpMetrics);

  }

  @PostMapping(value = "/metrics",
      produces = {"application/json"},
      consumes = {"application/json; charset=utf-8"})
  public ResponseEntity saveMetrics(
      @RequestParam(value = "index", required = true) String index,
      @RequestBody CMPRequestBody body){

    try{
      cmpService.save(index, body.getPayload());
      return ResponseEntity.ok().build();
    }
    catch(Exception e){
      return ResponseEntity.internalServerError().body(e.getMessage());
    }
  }

  @PutMapping(value = "/metrics",
      produces = {"application/json"},
      consumes = {"application/json; charset=utf-8"})
  public ResponseEntity updateMetrics(
      @RequestParam(value = "index", required = true) String index,
      @RequestParam(value = "id", required = true) String id,
      @RequestBody Object body) throws IOException {

    try{
      cmpService.update(index, id, body);
      return ResponseEntity.ok().build();
    }
    catch(Exception e){
      return ResponseEntity.internalServerError().body(e.getMessage());
    }
  }

  @DeleteMapping(value = "/metrics",
      produces = {"application/json"},
      consumes = {"application/json; charset=utf-8"})
  public ResponseEntity deleteMetrics(
      @RequestParam(value = "index", required = true) String index,
      @RequestParam(value = "id", required = true) String id) throws IOException {

    try{
      cmpService.delete(index, id);
      return ResponseEntity.ok().build();
    }
    catch(Exception e){
      return ResponseEntity.internalServerError().body(e.getMessage());
    }
  }
}
