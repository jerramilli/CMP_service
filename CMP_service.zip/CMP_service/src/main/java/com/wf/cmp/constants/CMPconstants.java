package com.wf.cmp.constants;

public class CMPconstants {

  public static final String created = "Created";

  public static final String updated = "Updated";

  public static final String notFound = "NotFound";

}
