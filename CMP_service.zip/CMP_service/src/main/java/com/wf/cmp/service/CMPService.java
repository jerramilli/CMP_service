package com.wf.cmp.service;

import static com.wf.cmp.constants.CMPconstants.created;
import static com.wf.cmp.constants.CMPconstants.notFound;
import static com.wf.cmp.constants.CMPconstants.updated;

import co.elastic.clients.elasticsearch.core.BulkResponse;
import co.elastic.clients.elasticsearch.core.DeleteResponse;
import co.elastic.clients.elasticsearch.core.IndexResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.wf.cmp.exception.ApiException;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CMPService {

  private Logger logger = LoggerFactory.getLogger(CMPService.class);

  private Gson gson = new Gson();

  private ObjectWriter ow;

  @Autowired
  private ElasticSearchService esService;

  public CMPService(){
    ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
  }


  public List<Hit<Object>> read(String index) throws IOException {
    logger.info("Started reading for all indices");

    try{
      List<Hit<Object>> hits = esService.read(index);
      logger.info(String.format("Successfully read index: %s and found no of hits: %s",
              index, hits.size()));


      return hits;

    }
    catch(Exception e){
      logger.error(String.format("Failed to read index: %s from elastic search, ex: %s", index, e.getCause()));
      throw new ApiException(String.format("Failed to read from Elastic Search index: %s , ex: %s", index, e.getMessage()));
    }

  }


  public void save(String index, List<Object> data) {

    List<String> docs = data.stream().map(o -> gson.toJson(o)).collect(Collectors.toList());

    logger.info("Trying to post documents to Elastic search index :"+ index);
    try{

      BulkResponse response = esService.bulkCreate(index, docs);

      if(response.errors()){
        logger.error(String.format("Failed to post to Elastic Search index: %s , errors: %s",
            index, response.items()));
      }
      else{
        logger.info("Successfully finished posting documents to Elastic search index : "+ index);
      }

    }
    catch(Exception e){
      logger.error(String.format("Failed to post to Elastic Search index: %s , ex: %s", index, e.getMessage()));
      throw new ApiException(String.format("Failed to post to Elastic Search index: %s , ex: %s", index, e.getMessage()));
    }

  }

  public void save(String index, Object data) throws IOException {
    String json = gson.toJson(data);
    IndexResponse response = esService.create(index, json);
    if(response.result().name().equalsIgnoreCase(created)){
      logger.info(String.format("document with data : %s at index: %s  has been created successfully.", json, index));
    }
    else {
      throw new ApiException(String.format("Unable to create the document with json : %s , in index: %s",
              json, index));
    }
  }

  public void update(String index, String id, Object data) throws IOException {
    String json = gson.toJson(data);
    IndexResponse response = esService.update(index, id, json);
    if(response.result().name().equalsIgnoreCase(updated)){
      logger.info(String.format("document with id: %s, given json : %s , at index: %s has been updated successfully.",
          id, json, index));
    }
    else{
      throw new ApiException(String.format("Unable to update document with Id : %s , with given json: %s, in index: %s",
              id, json, index));
    }
  }

  public void delete(String index, String id) throws IOException {
    DeleteResponse response = esService.delete(index, id);
    if (Objects.nonNull(response.result()) && !response.result().name().equalsIgnoreCase(notFound)) {
      logger.info("Document with id : " + response.id()+ " has been deleted successfully !.");
    }
    else {
      throw new ApiException("document with id : " + response.id()+" does not exist.");
    }

  }

}
