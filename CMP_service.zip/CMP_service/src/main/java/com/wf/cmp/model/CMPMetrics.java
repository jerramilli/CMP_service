package com.wf.cmp.model;

import co.elastic.clients.elasticsearch.core.search.Hit;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.JsonObject;

import java.util.List;
import java.util.stream.Collectors;

public class CMPMetrics {
    @JsonProperty("payload")
    private List<Object> payload;

    public  CMPMetrics(){

    }

    public CMPMetrics(List<Hit<Object>> payload) {
        this.payload = payload.stream().map(o -> (Object)o).collect(Collectors.toList());
    }

    public List<Object> getPayload() {
        return payload;
    }

    public void setPayload(List<Object> payload) {
        this.payload = payload;
    }
}
